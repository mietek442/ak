#################################################################
#
# Laboratorium 4. Konwersja liczby calkowitej bez znaku
# do postaci ciagu tekstowego (reprezentacja w systemie szesnastkowym).

.globl _start

#################################################################
#
# Alokacja pamieci - zmienne statyczne, 8/16/32/64-bitowe,
# z nadana wartoscia poczatkowa.

.data

# en.wikipedia.org/wiki/Hexspeak
# en.wikipedia.org/wiki/Magic_number_(programming)

var8:	.byte	237
var16:	.word	11181
var32:	.long	3735929054
var64:	.quad	18369614221190020847

#		"qqqqqqqqqqqqqqqqh"
#		"........llllllllh"
#		"............wwwwh"
#		"..............bbh"
str:	.ascii	"................h"

newline:.byte	0x0A

.equ	strlen, newline+1 - str

#################################################################
#
# Program glowny.

 .text

_start:

	xor	%eax , %eax	# %rax = 0

# Przekaz tylko niezbedne argumenty do funkcji konwertujacej,
# przykladowo:
# w %rax (ew. w jego czesci) liczbe podlegajaca konwersji,
# w %rdi (%edi) adres bufora - pozycji zapisu reprezentacji pierwszego bajtu,
# opcjonalnie w %rcx (%ecx) rozmiar konwertowanego typu danych w bajtach: (1),2,4,8.

	mov var64, %rax  #	jak zrobimy $etykieta to program bedzie działał ale wyswietlimy etykiete zmiennej, a jak bez to odczytamy wartos zmiennnej
	mov $newline-3 , %rdi  # przekazujemy z $ bo chcemy przekazać adres 
# Wywolaj funkcje konwertujaca.

	call	convert	

# Wyswietl wynik (system_call nr 1).

	mov	$1 , %eax
	mov	%eax , %edi
	mov	$str , %rsi
	mov	$strlen,%edx
	syscall

# Zakoncz program (system_call nr 60).

	mov	$60,%eax
	xor	%edi,%edi
	syscall

#################################################################
#
# Zadanie --- 3 ---
#
# Konwertuj wielobajtowy typ danych w oparciu o Lookup Table
# (plik lut16bit.s).
#
# Argumenty:
# liczba w rejestrze %rax (ew. w jego czesci),
# adres zapisu w %rdi (%edi),
# ew. liczba bajtow do konwersji w %ecx.
#
# Zwracana wartosc: - (zapis w pamieci).
# Nadpisywane rejestry: ustalic.

convert:

	# do adresowania pamięci służą 32 lub 64 bitowe
	mov	%rax , %rbx	#%rbx kopia liczby %raz czyli wrzucamy do wolnego rejestru tą liczbe
	and	$0b11111111 , %rbx # chodzi tu o wywalenie to samo to $0xFF zamiast tych jedynek ff to są 8 jedynek
	# w %rbx wartość 0 -255 czyli w szesnastkowym (0x00 - 0xFF)
	mov	lut16bit( , %rbx,2) ,%bx       #odczytaj dwa bajty zaczynając z adresu lut16bit+2*%rbx i zapisz je w rejestr %bx, (przesunięcie) ( , %rbx) - bo nie ma pierszego rejestru
	
	mov	%bx ,	(%rdi)	#zapisz dwa znaki ascii z %bx pod miejsce wskazane w %rdi
	
	sub	$2 , %rdi	# %rdi = %rdi-2

	shr	$8 , %rax	#przesun logicznie  o 8 bitów w prawo
	

	jnz	convert		# jump if zero, czyli powtarzaj jak nie jest zerem, powtarzaj dopoki nie zostal wysuniety ostatni bajt z %rax i przetworzony
	ret

#################################################################
