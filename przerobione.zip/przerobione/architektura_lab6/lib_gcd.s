.section  .note.GNU-stack, "", @progbits

.globl gcd

.text

.type	gcd,@function

gcd:
sub	$8 , %rsp

# Zabezpiecz odpowiednie rejestry przed nadpisaniem
# i wywolaj print_call.

push	%rdi
push	%rsi
call	print_call
pop	%rsi
pop	%rdi	# ważne aby sciągać na odwrót pierwszy wrzucony, ostatni odczytany

# Algorytm Euklidesa:
#
# unsigned int GCD(unsigned int a, unsigned int b) 
# { 
#   if (b==0) return a; 
#   else GCD(b, a % b); 
# } 
# a w %edi , b w %esi, wynik w %eax - zgodnie z abi

cmp	$0, %esi	#czy b (w %esi) =0? od 2 odejmij pierwszy i ustaw flage jak jet zerem
jz	return_gcd	#jeżeli tak - wyjdz z gcd, zwarcając a
xor 	%edx , %edx	#starsza polowa dzielnej = 0;
mov	%edi , %eax	# młodsza połowa dzielnej a z %edi idzie do %eax
div	%esi

mov	%esi , %edi	# b z drugiego argumentu do pierwszego
mov 	%edx , %esi	# reszta z dzielenia %edx wchodzi jako 2 argument

call	gcd	

return_gcd:

# Zabezpiecz odpowiednie rejestry przed nadpisaniem
# i wywolaj print_ret.

push	%rdi
push	%rsi
call	print_ret
pop	%rsi
pop	%rdi

# Zwroc obliczona wartosc w %eax.

mov	%edi , %eax	#zworc a w %edi w %eax zgodnie z abi

add	$8 , %rsp
ret

